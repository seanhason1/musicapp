package com.example.change;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText etText;
    Button butt;
    TextView tView;


    public double shekelToDollar(double shekel)
    {
        final double dollar = 3.77;
        return  dollar * shekel;

    }


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);

            etText = findViewById(R.id.etText);
            butt = findViewById(R.id.button);
            tView = findViewById(R.id.textView);

            butt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v)
                {
                    String input = etText.getText().toString();
                    double shekel = Double.parseDouble(input);
                    tView.setText(String.valueOf((shekelToDollar(shekel))));
                }
            }
            );






            return insets;
        });
    }
}